<?php

if($_GET['url']=='o_nas'){
    include('templates/STARTonas.php');
}elseif($_GET['url']=='wspolpraca'){
    include('templates/STARTwspolpraca.php');
}