<span style="color:white;"><?php

echo'$SITE:<br />';
print_r($site);
echo'<br /><br />$_POST:';
print_r($_POST);
echo'<br /><br />$adress:';
print_r($adress);
echo'<br /><br />$profil_e:';
print_r($profil_e);

$profil_e

?>
</span>