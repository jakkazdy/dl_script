<div class="divinfo">
    <div class="divinfotext">Paczka została zgłoszona do wysyłki.</div>
</div>