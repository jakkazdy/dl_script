
    <div class="divinfo">
      <div class="divinfotext">Podałeś/łaś błędny email bądź hasło, spróbuj ponownie!&nbsp;</div>
    </div>