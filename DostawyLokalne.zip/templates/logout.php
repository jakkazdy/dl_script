<div class="divinfo">
    <div class="divinfotext">Zostałeś wylogowany. Wróć do <a href="index.php">strony głównej</a>.</div>
</div>