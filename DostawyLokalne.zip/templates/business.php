<p>Dobry kierunek w e-commerce to ten w kierunku klienta.</p>
<p>Posiadasz sklep internetowy i chcesz aby klienci dostawali przesyłki błyskawicznie?<br/>
Współpracujemy z X lokalnymi firmami kurierskimi którzy zrobią wszystko aby dostarczyć paczkę do twojego klienta jak najszybciej.<br/>
<a href="index.php?url=business_rshop">Rozpocznij współpracę</a></p>
<p>Masz lokalną firmę kurierską albo chcesz zacząć pracować jako kurier?<br/>
Nie zwlekaj zarejestruj się a my już wkrótce się do Ciebie odezwiemy!<br/>
<a href="index.php?url=business_rcuriers">Dołącz do bazy kurierów</a></p>