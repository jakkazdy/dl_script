<div class="divinfo">
    <div class="divinfotext">Twoje konto jest już aktywne. Pamiętaj o weryfikacji adresu email.</div>
</div>