<div class="divinfo">
    <div class="divinfotext">Podana strona nie istnieje bądź nie masz do niej dostępu.</div>
</div>