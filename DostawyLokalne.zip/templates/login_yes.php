
    <div class="divinfo">
      <div class="divinfotext">Zostałeś zalogowany.&nbsp;</div>
    </div>
<?php
    include('include/index.php');
?>