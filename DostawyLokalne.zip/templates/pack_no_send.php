
<div class="divinfo">
    <div class="divinfotext">Nie uzupełniłeś wszystkich pól! Spróbuj ponownie.</div>
</div>