<div class="divinfo">
    <div class="divinfotext">Dane zostały zmienione! Aktualizacja cennika może jeszcze trochę potrwać.</div>
</div>