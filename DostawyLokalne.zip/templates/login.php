
    <div class="divinfo">
      <div class="divinfotext">Witaj gościu, zaloguj sie aby zarządzać swoimi zleceniami.&nbsp;</div>
    </div>
    <div class="w-container conform">
      <div class="divlogin">
        <div class="header">
          <h1 class="h1 h1a">Logowanie</h1>
        </div>
        <div class="w-form">
          <form class="formspace"  action="index.php?url=login" method="POST">
            <label class="namelabel formwidth" for="name">Adres email:</label>
            <input type="hidden" name="send" value="login"/>
            <input class="w-input inputform" id="name" type="email" placeholder="adres@dostawylokalne.pl" name="email" data-name="email"  required="required">
            <label class="namelabel formwidth" for="email">Wpisz hasło:</label>
            <input class="w-input inputform" id="name" type="password" placeholder="******" name="pass" data-name="pass">
            <input class="w-button buttonsend" name="sumbit" type="submit" value="Zaloguj się" data-wait="Trwa wysyłanie..." wait="Trwa wysyłanie...">
          </form>
        </div>
        <div class="divinfotext">Zapomniałeś hasła? Przypomnij!&nbsp;&nbsp;–&nbsp;&nbsp;Nie masz konta? Zarejestruj się!</div>
      </div>
    </div>
      