<p>Zmiana hasła:</p>
<form action="index.php?url=profil_h" method="POST">
    <br/><input type="hidden" name="send" value="ph"/>
    <p class="forml">Wpisz nowe hasło:</p><input type="password" name="p1" /><br/>
    <p class="forml">Powtórz nowe hasło:</p><input type="password" name="p2" /><br/>
    <p class="forml">Wprowadź aktualne hasło:</p><input type="password" name="p" /><br/>
    <input class="inputl" type="submit" name="submit" value="Zmień hasło"> 
</form> 
