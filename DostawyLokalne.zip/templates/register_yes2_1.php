<div class="divinfo">
    <div class="divinfotext">Zarejestrowałeś konto firmy. Uzupełnij dane adresowe i potwierdź adres email.</div>
</div>