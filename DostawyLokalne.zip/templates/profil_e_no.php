<div class="divinfo">
    <div class="divinfotext">Wystapił błąd przy zmianie danych.</div>
</div>