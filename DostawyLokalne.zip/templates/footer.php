    <div class="divinfo">
      <div class="divinfotext">DostawyLokalne.pl&nbsp;&nbsp;–&nbsp;&nbsp;Informacje dla klienta&nbsp;&nbsp;–&nbsp;&nbsp;Informacje dla firm&nbsp;&nbsp;–&nbsp;&nbsp;Współpraca&nbsp;&nbsp;– &nbsp;Regulamin&nbsp;&nbsp;–&nbsp;&nbsp;Kontakt</div>
    </div>
  </div>
  <script type="text/javascript" src="https://ajax.googleapis.com/ajax/libs/jquery/1.11.1/jquery.min.js"></script>
  <script type="text/javascript" src="js/webflow.js"></script>
  <!--[if lte IE 9]><script src="https://cdnjs.cloudflare.com/ajax/libs/placeholders/3.0.2/placeholders.min.js"></script><![endif]-->
</body>
</html>